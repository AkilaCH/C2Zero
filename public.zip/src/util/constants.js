export const Constants = {
  claims: 'claims',
  token: 'token'
};

export const purchasedECertificateOrderStatus = Object.freeze({
  ALL: 'ALL',
  PENDING: 'PENDING',
  COMPLETED: 'COMPLETED'
});
